  const sheet = SpreadsheetApp.openById("11hVUD7eS3ZHr1PqLSvOgbXO52lQUXB-pCUFwaKRX5Ac").getSheetByName("Sheet2");
  const timestamp = new Date();
  let data;

  try {
    data = JSON.parse(e.postData.contents);
  } catch (err) {
    return ContentService.createTextOutput("❌ Invalid JSON");
  }

  const callId = data.call_id || "";
  const botName = data.bot_name || "";
  const phoneNumber = data.phone_number || "";
  const callDate = data.call_date || "";
  const userEmail = data.user_email || "";
  const report = data.call_report || {};
  const summary = report.summary || "";
  const transcript = report.transcript || "";
  const recording = report.recording_url || "";
  const sentiment = report.sentiment || "";
  let variables = report.extracted_variables || {};

  // Debug logging - Add this to see what's being received
  Logger.log("Received variables: " + JSON.stringify(variables));
  Logger.log("Raw transcript: " + transcript);
  
  // Enhanced location extraction
  let userLocation = variables.user_location || "";
  
  // Also check for alternate field names that OmniDim might use
  if (!userLocation) {
    userLocation = variables.location || variables.user_area || variables.city || "";
  }
  
  if (!userLocation && transcript) {
    // Improved regex patterns for location extraction
    const locationPatterns = [
      /(?:near|in|at|around|from|to|charging in|to the)\s+(?:the\s+)?([A-Za-z][A-Za-z\s,.-]+(?:road|city|town|area|street|avenue|district|locality|nagar|colony)?)/i,
      /(?:I'm|I am)\s+(?:in|at|near)\s+([A-Za-z][A-Za-z\s,.-]+)/i,
      /(?:located|living|staying)\s+(?:in|at|near)\s+([A-Za-z][A-Za-z\s,.-]+)/i,
      /([A-Za-z][A-Za-z\s,.-]+)\s+(?:road|area|city|town|district|nagar)/i,
      /find.*?(?:near|in|at)\s+([A-Za-z][A-Za-z\s,.-]+)/i
    ];
    
    for (let pattern of locationPatterns) {
      const match = transcript.match(pattern);
      if (match && match[1]) {
        userLocation = match[1].trim().replace(/[^\w\s,.-]/g, "");
        // Clean up common false positives
        if (userLocation.length > 3 && !userLocation.match(/^(the|and|for|with|this|that|station|charging)$/i)) {
          break;
        }
      }
    }
  }
  
  Logger.log("Final extracted location: " + userLocation);

  const selectedStation = variables.selected_station || "";
  let selectedSlot = variables.selected_time_slot || "";

  // Enhanced time slot extraction
  if (!selectedSlot && transcript) {
    const slotPatterns = [
      /(?:book|schedule|slot|time|appointment)\s*(?:for|at)?\s*(\d{1,2}(?::\d{2})?\s*(?:AM|PM|am|pm))/i,
      /(\d{1,2}(?::\d{2})?\s*(?:AM|PM|am|pm))/i,
      /(?:at|around|about)\s*(\d{1,2}(?::\d{2})?)\s*(?:o'?clock)?/i
    ];
    
    for (let pattern of slotPatterns) {
      const slotMatch = transcript.match(pattern);
      if (slotMatch) {
        selectedSlot = slotMatch[1];
        // Normalize time format
        if (!selectedSlot.match(/AM|PM/i) && selectedSlot.match(/^\d{1,2}$/)) {
          const hour = parseInt(selectedSlot);
          selectedSlot = hour < 12 ? `${hour}:00 AM` : `${hour}:00 PM`;
        }
        break;
      }
    }
  }

  const evRequested = /ev station|charging station|ev charger|electric vehicle|charge my car|charging slot|ev charging/i.test(summary + ' ' + transcript);
  let evInfo = "";
  let stationDetails = "";

  if (evRequested) {
    if (userLocation) {
      // Actually call the function to find nearest EV station
      stationDetails = findNearestEVStation(userLocation);
      evInfo = `Nearest EV station: ${stationDetails}`;
    } else {
      evInfo = "User requested EV service but location could not be determined.";
    }
  }

  // Enhanced email sending logic with spam prevention
  if (selectedSlot && userEmail && evRequested) {
    // Send confirmation email when slot is booked
    const confirmationBody = `Dear ${variables.user_name || 'Customer'},

🎉 Your EV charging slot has been successfully confirmed!

BOOKING DETAILS:
📅 Date: ${new Date().toLocaleDateString('en-IN')}
🕒 Time: ${selectedSlot}
📍 Station: ${stationDetails || 'Nearest available charging station'}
${userLocation ? `🗺️ Location: ${userLocation}` : ''}

IMPORTANT REMINDERS:
• Please arrive 5-10 minutes before your scheduled time
• Bring your charging cable if required
• Keep this confirmation for your records

Need to make changes? Contact us immediately.

Thank you for choosing ChargeFinder!

Best regards,
ChargeFinder Team
www.chargefinder.com`;

    sendReminderEmail(userEmail, "✅ EV Charging Slot Confirmed - " + selectedSlot, confirmationBody);
    
  } else if (evRequested && userEmail && !selectedSlot) {
    // Send station info and available slots when EV requested but no slot booked
    const infoBody = `Dear Customer,

Thank you for your interest in EV charging services!

STATION INFORMATION:
${stationDetails ? `📍 Recommended Station: ${stationDetails}` : '📍 We are finding the best stations for you'}
${userLocation ? `🗺️ Your Area: ${userLocation}` : ''}

AVAILABLE SLOTS TODAY:
🕐 11:00 AM - Available
🕐 12:40 PM - Available  
🕕 03:00 PM - Available
🕕 05:30 PM - Available
🕕 07:40 PM - Available

HOW TO BOOK:
• Call us back to reserve your preferred slot
• Or reply to this email with your preferred time
• Booking confirmation will be sent immediately

Questions? We're here to help!

Best regards,
ChargeFinder Team
Support: +91-XXXXXXXXXX`;

    sendReminderEmail(userEmail, "📍 EV Charging Stations Near You", infoBody);
  }

  // Enhanced response text
  const responseText =
    `✅ Call Processed Successfully\n` +
    `📞 Call ID: ${callId}\n` +
    `📍 Location: ${userLocation || 'Not detected'}\n` +
    `🔌 EV Request: ${evRequested ? 'Yes' : 'No'}\n` +
    `🏪 Station: ${stationDetails || 'Not found'}\n` +
    `🕒 Slot: ${selectedSlot || 'Not booked'}\n` +
    `📧 Email: ${userEmail ? 'Sent' : 'Not available'}`;

  // Log to spreadsheet
  sheet.appendRow([
    Utilities.formatDate(timestamp, Session.getScriptTimeZone(), "dd/MM/yyyy HH:mm:ss"),
    callId, botName, phoneNumber, callDate, userEmail, userLocation,
    selectedStation || stationDetails, selectedSlot, summary, sentiment, evInfo,
    transcript, recording, JSON.stringify(data), responseText
  ]);

  return ContentService.createTextOutput(responseText);
}

function findNearestEVStation(userAddress) {
  const apiKey = "AIzaSyCnEof_8_dbPBggHmWYkQYs54PHbBo3Mh0";  // Consider moving to PropertiesService for security

  try {
    // Geocode the user address
    const geoRes = UrlFetchApp.fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(userAddress)}&key=${apiKey}`);
    const geoData = JSON.parse(geoRes.getContentText());
    
    if (!geoData.results || geoData.results.length === 0) {
      return "Location not found. Please provide a more specific address.";
    }

    const { lat, lng } = geoData.results[0].geometry.location;

    // Search for EV charging stations
    const placeRes = UrlFetchApp.fetch(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lng}&radius=10000&keyword=electric vehicle charging station&key=${apiKey}`);
    const placeData = JSON.parse(placeRes.getContentText());
    
    if (!placeData.results || placeData.results.length === 0) {
      // Try alternative search
      const altPlaceRes = UrlFetchApp.fetch(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lng}&radius=15000&type=gas_station&keyword=charging&key=${apiKey}`);
      const altPlaceData = JSON.parse(altPlaceRes.getContentText());
      
      if (!altPlaceData.results || altPlaceData.results.length === 0) {
        return "No EV charging stations found within 15km radius.";
      }
      
      placeData.results = altPlaceData.results;
    }

    const station = placeData.results[0];
    const stationName = station.name;
    const stationAddress = station.vicinity || station.formatted_address || 'Address not available';
    const stationCoords = `${station.geometry.location.lat},${station.geometry.location.lng}`;
    const rating = station.rating ? ` (★${station.rating})` : '';

    // Get distance information
    const distRes = UrlFetchApp.fetch(`https://maps.googleapis.com/maps/api/distancematrix/json?origins=${lat},${lng}&destinations=${stationCoords}&units=metric&key=${apiKey}`);
    const distData = JSON.parse(distRes.getContentText());
    
    let distance = 'Distance unavailable';
    let duration = '';
    
    if (distData.rows && distData.rows[0] && distData.rows[0].elements && distData.rows[0].elements[0]) {
      const element = distData.rows[0].elements[0];
      if (element.status === 'OK') {
        distance = element.distance.text;
        duration = ` (${element.duration.text} drive)`;
      }
    }

    return `${stationName}${rating}, ${stationAddress} - ${distance}${duration}`;
    
  } catch (err) {
    Logger.log("EV Locator Error: " + err.toString());
    return "Error locating charging station. Please try again later.";
  }
}

function sendReminderEmail(to, subject, body) {
  try {
    // Method 1: Simple Gmail send (most reliable)
    GmailApp.sendEmail(to, subject, body, {
      name: 'ChargeFinder EV Assistant'
    });
    Logger.log(`✅ Email sent successfully to ${to}`);
    return true;
  } catch (error) {
    Logger.log(`❌ Failed to send email to ${to}: ${error.toString()}`);
    
    // Method 2: Fallback with HTML formatting to avoid spam
    try {
      const htmlBody = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; text-align: center; color: white;">
            <h2>🔌 ChargeFinder</h2>
          </div>
          <div style="padding: 20px; background: #f8f9fa;">
            ${body.replace(/\n/g, '<br>')}
          </div>
          <div style="padding: 10px; text-align: center; font-size: 12px; color: #666;">
            This is an automated message from ChargeFinder EV Assistant
          </div>
        </div>
      `;
      
      GmailApp.sendEmail(to, subject, '', {
        name: 'ChargeFinder EV Assistant',
        htmlBody: htmlBody
      });
      Logger.log(`✅ Email sent with HTML fallback to ${to}`);
      return true;
    } catch (fallbackError) {
      Logger.log(`❌ Both email methods failed: ${fallbackError.toString()}`);
      return false;
    }
  }
}

// Function to validate email before sending
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Function to add delay between emails (prevents spam flagging)
function addEmailDelay() {
  Utilities.sleep(2000); // 2 second delay
}
function debugReceivedData(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    Logger.log("=== FULL WEBHOOK DATA ===");
    Logger.log(JSON.stringify(data, null, 2));
    Logger.log("=== EXTRACTED VARIABLES ===");
    Logger.log(JSON.stringify(data.call_report?.extracted_variables || {}, null, 2));
    Logger.log("=== TRANSCRIPT ===");
    Logger.log(data.call_report?.transcript || "No transcript");
    return ContentService.createTextOutput("Debug data logged");
  } catch (err) {
    Logger.log("Debug Error: " + err);
    return ContentService.createTextOutput("Debug Error: " + err);
  }
}

// Optional: Test function to verify location extraction
function testLocationExtraction() {
  const testTranscripts = [
    "find charging station near Nashik road, book slot to nearest by shreya",
    "I need charging near Mumbai Central",
    "Looking for charging station around Andheri",
    "Can you find charging near my location in Powai"
  ];
  
  testTranscripts.forEach(transcript => {
    console.log(`Testing: ${transcript}`);
    // Add your location extraction logic test here
  });
}